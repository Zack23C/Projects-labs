
<!DOCTYPE html>

<html>

    <head>
    
        <title>About Us</title>
        
        <meta name="Book Lovers" content="The ultimate page for great books from all over the world"/>
      
        <meta charset="utf-8"/>
        
        <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
        
        <link rel="stylesheet" type="text/css" href="Lab4.css"/>
        
    </head>
    
    <body>
    
        <div id="wrap">
            
            <?php 
            
            include('header.php');
            
            ?>
            
         
            
                <div class="lid">
                <div class="top">
                    
                       
                    <div>
                        
                        <h3>All About Us</h3>
                    
                        <p>We love books as much as you do. The books blood runs throught us and we shall forever hail the books!</p>
                        
	                   <img class="about us" src="aboutus.png" alt="toppicture" width="50%" height="10%">
                        
                    </div>
                
                </div>
            
           <footer>
              <?php include('footer.php');?>  
           </footer>
            
           
        
        </div>
        </div>
    </div>
    </body>

</html>