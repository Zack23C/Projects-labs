<footer>
    
    <p>&copy; Copyright 2017, All rights reserved, Zack's  Club </p>
    
</footer>