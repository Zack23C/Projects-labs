


<?php


include('config4.php');


?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body> 
<header id="pageheader">


                <div id="mneu">
            <h6></h6>
            <img src="hamburger.png" id="hamber">
            <nav>
                <ul id="top" class="nav1">
                    <li>
 <a class="<?php echo ($current_page == 'main_login2.php' || $current_page == '') ? 'active' : NULL ?>" href="main_login2.php"> Home</a>
                               </li>
                    <li>
         <a class="<?php echo ($current_page == 'addbook.php') ? 'active' : NULL ?>" href="addbook.php">Add book</a>
                    </li>
                    <li>
         <a class="<?php echo ($current_page == 'deletebook.php') ? 'active' : NULL ?>" href="deletebook.php">Delete book</a>
                    </li>
                    <li>
        <a class="<?php echo ($current_page == 'gallery.php') ? 'active' : NULL ?>" href="gallery.php"> Gallery</a>
                        
                    </li>
                        
                       <li>   
        <a class="<?php echo ($current_page == 'logout2.php') ? 'active' : NULL ?>" href="logout2.php">Log Out</a>
                    </li>    
                </ul>
            </nav>
             </div>
        </header>

</body>
</html>







