<!doctype html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body> 
<header id="pageheader">
				<div id="mneu">
			<h6></h6>
			<img src="hamburger.png" id="hamber">
			<nav>
				<ul id="top" class="nav1">
					<li>
						<a class="<?php echo ($current_page == 'ass6.php' || $current_page == "") ? 'active' : NULL ?>"href="ass6.php">Home</a>
					</li>
					<li>
						<a class="<?php echo ($current_page == 'home.php') ? 'active' : NULL ?>" href="home.php">About US</a>
					</li>
					<li>
						<a class="<?php echo ($current_page == 'browse.php') ? 'active' : NULL ?>" href="browse.php">Browse books</a>
					</li>
					<li>
						<a class="<?php echo ($current_page == 'contactUs.php') ? 'active' : NULL ?>" href="contactUs.php">Contact us</a>
					</li>
						
	                   <li>   
						<a class="<?php echo ($current_page == 'mybooks.php') ? 'active' : NULL ?>" href=" mybooks.php">My books</a>
					</li>	
				</ul>
			</nav>
             </div>
		</header>

</body>
</html>