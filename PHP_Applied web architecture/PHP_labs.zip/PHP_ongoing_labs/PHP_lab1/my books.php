<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="ass51.css">
<link rel="stylesheet" type="text/css" href="jsf/flexslider.css">
<meta charset="utf-8"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script src="jsf/jquery.flexslider.js"></script>
<script type="text/javascript" src="jsf/a5.js"></script>
<script type="text/javascript" charset="utf-8">
  $(window).load(function() {
    $('.flexslider').flexslider();
  });
</script>
</figure>
</head>
<body>
	<div id="wholepage">
		
		
			<header id="pageheader">
				<div id="mneu">
			<h6>CHECK YOUR BOOKS</h6>
			<img src="hamburger.png" id="hamber">
			<nav>
				<ul id="top" class="nav1">
					<li>
						<a href="ass6.php">Home</a>
					</li>
					<li>
						<a href="home.php">About US</a>
					</li>
					<li>
						<a href="contacts us.php">Contact us</a>
					</li>
					<li>
						<a href="">My books</a>
					</li>	
				</ul>
			</nav>
		</div>
		</header>

	<div id="maincolumn">

<div class="flexslider">

  <ul class="slides">
  	<li>
  		<figure class="bigimage">
		<img src="library.jpg">
		<h1>Welcome to <p> ZACKS LIBRAY</p></h1>
	</figure>
    </li>

    <li>
    <figure class="bigimage">
      <img src="library.jpg">
      <h1>All books<p>Corner</p></h1>
	</figure>
    </li>

    <li>
       <figure class="bigimage">
      <img src="library.jpg" >
      <h1>All books<p>Corner</p></h1>
      </figure>
    </li>

    <li>
    	<figure class="bigimage">
      <img src="library.jpg">
      <h1>All books<p>Corner</p></h1>
      </figure>
    </li>

  </ul>

</div>
    <ul id="buttons">
    	<li>
	<a href="#" class="bigbutton">You have 2 books now</a>
	</li>

	<li>
	<a href="#" class="bigbutton1">Add more books</a>
	</li>
</ul>
<ul id="books">
<img src="hello.jpg">
<img src="php.png">
</ul>
<footer class="fot">
	<P>Copyrights 2016,All rights reserved,Happening Inc.</p>
	</footer>

</body>
</html>