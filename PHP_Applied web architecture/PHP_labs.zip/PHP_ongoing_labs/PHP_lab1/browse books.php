<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="ass51.css">
<link rel="stylesheet" type="text/css" href="jsf/flexslider.css">
<meta charset="utf-8"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script src="jsf/jquery.flexslider.js"></script>
<script type="text/javascript" src="jsf/a5.js"></script>
<script type="text/javascript" charset="utf-8">
  $(window).load(function() {
    $('.flexslider').flexslider();
  });
</script>
</figure>
</head>
<body>
	<div id="wholepage">
		
		
			<header id="pageheader">
				<div id="mneu">
			<h6>SEARCH YOUR BOOKS HERE</h6>
			<img src="hamburger.png" id="hamber">
			<nav>
				<ul id="top" class="nav1">
					<li>
						<a href="ass6.php">Home</a>
					</li>
					<li>
						<a href="home.php">About US</a>
					</li>
					<li>
						<a href="contacts us.php">Contact us</a>
					</li>
					<li>
						<a href="my books.php">My books</a>
					</li>	
				</ul>
			</nav>
		</div>
		</header>

	<div id="maincolumn">

<div class="flexslider">

  <ul class="slides">
  	<li>
  		<figure class="bigimage">
		<img src="library.jpg">
		<h1>Welcome to <p> ZACKS LIBRAY</p></h1>
	</figure>
    </li>

    <li>
    <figure class="bigimage">
      <img src="library.jpg">
      <h1>All books<p>Corner</p></h1>
	</figure>
    </li>

    <li>
       <figure class="bigimage">
      <img src="library.jpg" >
      <h1>All books<p>Corner</p></h1>
      </figure>
    </li>

    <li>
    	<figure class="bigimage">
      <img src="library.jpg">
      <h1>All books<p>Corner</p></h1>
      </figure>
    </li>

  </ul>

</div>
    

<form id="contact">
Name of the book<br>
	<input type="text" name="name" required="true">
	<br>
    Author<br>
    <input type="email" name="name" required="true">
    <br> 
    Eddition?<br>
    <input type="text" name="name">
    <br>
     <input type="submit" name="search" value="search">
	</form>

	<footer class="fot">
	<P>Copyrights 2016,All rights reserved,Happening Inc.</p>
	</footer>

</body>
</html>