<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="ass51.css">
<link rel="stylesheet" type="text/css" href="jsf/flexslider.css">
<meta charset="utf-8"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script src="jsf/jquery.flexslider.js"></script>
<script type="text/javascript" src="jsf/a5.js"></script>
<script type="text/javascript" charset="utf-8">
  $(window).load(function() {
    $('.flexslider').flexslider();
  });
</script>
</figure>
</head>
	<?php include 'config.php'; ?>


<body>
	<div id="wholepage">
		
	<?php include 'header.php'; ?>

	<div id="maincolumn">

<div class="flexslider">

  <ul class="slides">
  	<li>
  		<figure class="bigimage">
		<img src="library.jpg">
		
		<h1>Welcome to <p> ZACKS LIBRAY</p></h1>
	</figure>
    </li>

    <li>
    <figure class="bigimage">
      <img src="library.jpg">
      <h1>All books<p>Corner</p></h1>
	</figure>
    </li>

    <li>
       <figure class="bigimage">
      <img src="library.jpg" >
      <h1>All books<p>Corner</p></h1>
      </figure>
    </li>

    <li>
    	<figure class="bigimage">
      <img src="library.jpg">
      <h1>All books<p>Corner</p></h1>
      </figure>
    </li>

  </ul>

</div>
    
<h1>Search books</h1>
<form id="contact" action="browse.php" method="GET" >
Name of the book<br>
	<input type="text" name="name" required="false">
	<br>
    Author<br>
    <input type="text" name="author">

    <br> 
    
    
    <br>
     <input type="submit" name="search" value="search">
	</form>

	<!--<footer class="fot">
	<P>Copyrights 2016,All rights reserved,Happening Inc.</p>
	</footer> -->
	
</div>
			<!--<header id="pageheader">
				<div id="mneu">
			<h6>SEARCH YOUR BOOKS HERE</h6>
			<img src="hamburger.png" id="hamber">
			<nav>
				<ul id="top" class="nav1">
					<li>
						<a href="ass6.php">Home</a>
					</li>
					<li>
						<a href="home.php">About US</a>
					</li>
					<li>
						<a hrf="browse books.php">Browse books</a>
					</li>
					<li>
						<a href="contacts us.php">Contact us</a>
					</li>
					<li>
						<a href="my books.php">My books</a>
					</li>	
				</ul>
			</nav>

		</div>
		</header>-->
<h1>Book list</h1>
<!--</br>
<p>search by tittles:</p></br>
<form action="book list.php" method="POST" 
<table>
<td>Book Tittles:</td>
<td><input type="text" name="book"></td>
</tr>
<td></tr>
<td><input type="submit" name="submit" value="submit"></td>
</table>
</form>-->

<?php
$arrayCorny = array();
$arrayCorny[]= array("heading"=>"Hello world","Author"=>"Warren Sande");
$arrayCorny[]=array("heading"=>"PHP and Mysql","Author"=>"Janet Valade");
$arrayCorny[]=array("heading"=>"Physics","Author"=>"Tom Dancern");
$arrayCorny[]=array("heading"=>"Biology","Author"=>"Johns and Jones");

if(isset($_GET)&&!empty($_GET)){

	$name=trim($_GET['name']);
    $author=trim($_GET['author']);

	$name=addslashes($name);
    $author=addslashes($author);

    $getbook=array_search($name, array_column($arrayCorny,"heading"));
	$author=array_search($author, array_column($arrayCorny,"Author"));

	echo '<table bgcolor="#bdc0ff" cellpadding="6">';
	echo '<tr><td>Title</td> <td>Author</td> <td>Reserve</td></tr>';
	echo $getbook;
	if($getbook !== FALSE){
		$book = $arrayCorny[$getbook];
		$name = $book['heading'];
		$author = $book['Author'];
		  echo "</tr>";
    echo "<td> $name</td><td> $author</td>";
    echo '<td><a href="reserve.php?reservations=' . urlencode($name) .'">Reserve</a></td>';
    echo "</tr>";
}
	else if($author!==FALSE){
		$book = $arrayCorny[$author];
		$name = $book['heading'];
		$author = $book['Author'];
		  echo "</tr>";
    echo "<td> $name</td><td> $author</td>";
    echo '<td><a href="reserve.php?reservations=' . urlencode($name) .'">Reserve</a></td>';
    echo "</tr>";
}
	echo"</table>";
}else{
   /*if(isset($_Cookie['colorpreferences']));
   	    $colorpreferences = $_Cookie['colorpreferences'];
   	
   		$colorpreferences = "red";*/

	   /*echo 'table bgcolor="#bdc0ff" . $colorpreferences . "" cellpadding="6">';*/
	   echo '<tr><b><td>Title</td> <td>Author</td> <td>Reserve</td> </b> </tr>';
	   foreach ($arrayCorny as $book) {
	   	$name= $book['heading'];
	   	$author=$book['Author'];
	   	echo "<tr>";
	   	echo '<td><a href="reserve.php?reservations=' . urlencode($name) . '"> Reserve </a></td>';
	   	echo "</tr>"; 
	   }
	   echo "</table>";
	}
?>

	
</body>
<?php include ('footer.php'); ?>
</html>