<!doctype html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php 
echo "<p> <hr>Copyrights 2017,All rights reserved,Zack Inc </p>";
/*$styleTable =array('borderSize'=>)*/
		

?>
</body>
</html>